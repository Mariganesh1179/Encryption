from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes

def encrypt_message(public_key_pem, message):
    # Load the public key
    public_key = serialization.load_pem_public_key(public_key_pem)

    # Encrypt the message
    encrypted_message = public_key.encrypt(
        message.encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    
    return encrypted_message

# Read public key
with open("weak_public_key.pem", "rb") as f:
    public_key_pem = f.read()

# Define the message containing the flag
flag_message = "Talent_hunt{Successfully_founded}"
encrypted_message = encrypt_message(public_key_pem, flag_message)

with open("encrypted_flag_message.bin", "wb") as f:
    f.write(encrypted_message)

print("Message encrypted and saved to 'encrypted_flag_message.bin'")
